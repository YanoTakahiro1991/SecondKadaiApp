import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!

    var x:String = "「名前を入力してください」"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let result = "「こんにちは、さん」"
        label.text = " \(result) "
       
    }
}
